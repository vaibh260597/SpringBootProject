package com.example.demo.service;

import java.util.List;

import com.example.demo.entity.Course;
import com.example.demo.entity.Student;

public interface CourseService {

	//Course saveCourse(Course course);

	//List<Course> fetchcourList();

	Course saveCourse(Course course);

	List<Course> fetchcourList();

}
